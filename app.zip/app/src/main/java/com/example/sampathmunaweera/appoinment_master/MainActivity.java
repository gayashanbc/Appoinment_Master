package com.example.sampathmunaweera.appoinment_master;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CalendarView.OnDateChangeListener;
import android.widget.EditText;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {

    int selectedy;
    int selectedm;
    int selectedd;
    final Context context = this;
    private EditText result;
    private String c_title = "";
    private String c_dec = "";
    private String c_time = "";
    private String etStr;
    private String etStr1;

    CalendarView calendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // this can be add to make calendar
        calendar = (CalendarView) findViewById(R.id.calendar);


        calendar.setOnDateChangeListener(new OnDateChangeListener(){

            @Override
            public void onSelectedDayChange(CalendarView view,
                                            int year, int month, int dayOfMonth) {
                Toast.makeText(getApplicationContext(),
                        dayOfMonth +"/"+month+"/"+ year,Toast.LENGTH_LONG).show();

                selectedd = dayOfMonth;
                selectedm = month;
                selectedy = year;

                System.out.println(" Selected Date = "+selectedd+selectedm+selectedy);
            }
        });

        //exit
        Button btnexit = (Button) findViewById(R.id.exit);
        btnexit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // exit from app
                finish();
                System.exit(0);
            }

        });


        //create appoinment

        Button btncreate = (Button) findViewById(R.id.create);
        btncreate.setOnClickListener(new View.OnClickListener() {





            @Override
                public void onClick(View arg0) {

                Intent createIntend = new Intent(getApplicationContext(),CreateActivity.class);
                startActivity(createIntend);

                /*AlertDialog.Builder builder = new AlertDialog.Builder(context);


                LinearLayout layout = new LinearLayout(context);
                LinearLayout.LayoutParams parms = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                layout.setOrientation(LinearLayout.VERTICAL);
                layout.setLayoutParams(parms);

                layout.setGravity(Gravity.CLIP_VERTICAL);
                layout.setPadding(2, 2, 2, 2);

                TextView tv = new TextView(context);
                tv.setText("Create Appointment");
                tv.setPadding(40, 40, 40, 40);
                tv.setGravity(Gravity.CENTER);
                tv.setTextSize(20);


                TextView tv1 = new TextView(context);
                tv1.setText("Appointment Title");
                final EditText et = new EditText(context);
                etStr = et.getText().toString();
                LinearLayout.LayoutParams tv1Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                tv1Params.bottomMargin = 5;
                layout.addView(tv1,tv1Params);
                layout.addView(et, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


                final EditText inputTime = new EditText(context);
                final TimePicker tmpkr = new TimePicker (context);




                TextView tv3 = new TextView(context);
                tv3.setText("Appointment Time");
                LinearLayout.LayoutParams tv3Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                tv3Params.topMargin = 25;
                layout.addView(tv3,tv3Params);
                layout.addView(tmpkr, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


                final EditText inputDec = new EditText(context);
                etStr1 = inputDec.getText().toString();
                TextView tv2 = new TextView(context);
                tv2.setText("Appointment Description");
                LinearLayout.LayoutParams tv2Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                tv2Params.topMargin = 45;
                layout.addView(tv2,tv2Params);
                layout.addView(inputDec, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


                builder.setView(layout);
                builder.setCustomTitle(tv);



                // Set up the buttons
                builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        c_title = et.getText().toString();
                        c_dec = inputDec.getText().toString();




                        System.out.println( " c title set"+ c_title);
                        System.out.println( " c dec set"+ c_dec);
                        System.out.println( " c dec set"+ c_time);
                    }
                });


                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();*/



                }





        });


    }


}
