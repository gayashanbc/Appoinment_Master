package com.example.sampathmunaweera.appoinment_master;

/**
 * Created by sampathmunaweera on 3/25/17.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import static android.content.Context.MODE_PRIVATE;

public class DBAdapter {

    private static final String DATABASE_TABLE = "AppoinmentDB";
    public static final String KEY_ROW_ID = "_id";
    public static final String KEY_USERNAME = "sam";
    public static final String KEY_PASSWORD = "123";

    SQLiteDatabase mDb;
    Context mCtx;
    DBHelper mDbHelper;

    public DBAdapter(Context context)
    {
        this.mCtx = context;
       open();


    }

    public DBAdapter open() throws SQLException
    {
        mDbHelper = new DBHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close()
    {
        mDbHelper.close();
    }

    public long insertAppoinment(String title,String dec)
    {
        System.out.println("insertAppoinment"+title+"  insertAppoinment"+dec);

        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_USERNAME, title);
        initialValues.put(KEY_PASSWORD, dec);

        return mDb.insert(DATABASE_TABLE, null,initialValues);
    }

    public boolean Login(String username, String password) throws SQLException
    {
        Cursor mCursor = mDb.rawQuery("SELECT * FROM " + DATABASE_TABLE + " WHERE username=? AND password=?", new String[]{username,password});
        if (mCursor != null) {
            if(mCursor.getCount() > 0)
            {
                return true;
            }
        }
        return false;
    }

}
