package com.example.sampathmunaweera.appoinment_master;

import android.content.Context;
import android.database.SQLException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateActivity extends AppCompatActivity {



    DBAdapter dbAdapter;
    EditText getTitle;
    EditText getDec;
    Context contex;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        contex=this;


        Button btnsave = (Button)findViewById(R.id.save);

        getTitle   = (EditText)findViewById(R.id.title);
        getDec   = (EditText)findViewById(R.id.dec);

        btnsave.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Log.v("EditText", getTitle.getText().toString());
                Log.v("EditText", getTitle.getText().toString());
                String c_title = getTitle.getText().toString();
                String c_dec = getDec.getText().toString();



                try{

                    System.out.println("@@@@@@@@@"+c_title);
                    System.out.println("########"+c_dec);

                    dbAdapter = new DBAdapter(contex);
                    long i = dbAdapter.insertAppoinment(c_title,c_dec);

                    System.out.println("-------------"+c_title);
                    System.out.println("------------"+c_dec);

                    if(i != -1){
                        Toast.makeText(CreateActivity.this,"Done",Toast.LENGTH_LONG).show();
                    }

                }catch (SQLException e)
                {
                    Toast.makeText(CreateActivity.this,"Error Occured",Toast.LENGTH_LONG).show();
                }


            }

        });



    }
}
